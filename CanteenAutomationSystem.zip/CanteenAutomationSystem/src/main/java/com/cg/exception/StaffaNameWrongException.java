package com.cg.exception;

import org.springframework.context.annotation.Conditional;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StaffaNameWrongException extends RuntimeException{
	private String message;

}
