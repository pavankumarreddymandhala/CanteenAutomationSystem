package com.cg.service;

import java.util.List;

import com.cg.dto.AdminDto;
import com.cg.dto.CanteenStaffDto;
import com.cg.entity.CanteenStaff;
import com.cg.exception.AdminIdNotFoundException;
import com.cg.exception.StaffNotFoundException;
public interface ICanteenStaffService {
	public CanteenStaffDto signIn(Long staffId,CanteenStaffDto user) throws StaffNotFoundException;

	List<CanteenStaffDto> getAllStaff();
	CanteenStaffDto getStaffById(Long staffId);
	CanteenStaffDto saveStaff(CanteenStaffDto staff);
	CanteenStaffDto updateStaff(Long staffId,CanteenStaffDto staff);
	void deleteStaff(Long staffId);
	//public CanteenStaffDto signIn(Long staffId,CanteenStaffDto staff);

	
}
