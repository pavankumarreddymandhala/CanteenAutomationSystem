//package com.cg.canteenAutomationSystem.CanteenAutomationSystem.orderController;
//
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.cg.controller.AdminController;
//import com.cg.controller.OrderController;
//import com.cg.dto.AdminDto;
//import com.cg.dto.OrderDto;
//import com.cg.service.IAdminService;
//import com.cg.service.IOrderService;
//
//@ExtendWith(MockitoExtension.class)
//public class AdminControllerTest {
//	@InjectMocks
//	AdminController adminController;
//	@Mock
//	IAdminService  iAdminService;
//	@Test
//	void getAllTest() {
//		List<AdminDto> orders = createOrdersDtoMockData();		
//		when(iOrderService.getAllOrders()).thenReturn(orders);
//		List<OrderDto> orderList = orderController.getAllOrders();
//		assert(orders.size() == orderList.size());
//		
//	}
//
//}
