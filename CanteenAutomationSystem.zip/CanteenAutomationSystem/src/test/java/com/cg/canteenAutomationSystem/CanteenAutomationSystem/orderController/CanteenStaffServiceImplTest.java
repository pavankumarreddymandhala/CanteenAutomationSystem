package com.cg.canteenAutomationSystem.CanteenAutomationSystem.orderController;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.dto.CanteenStaffDto;
import com.cg.entity.CanteenStaff;
import com.cg.repository.CanteenStaffRepository;
import com.cg.service.seviceImpl.CanteenStaffServiceImpl;
@ExtendWith(MockitoExtension.class)

public class CanteenStaffServiceImplTest {
	@InjectMocks
	CanteenStaffServiceImpl canteenStaffService;
	
	@Mock
	CanteenStaffRepository canteenStaffRepository;
	@Test
	void getAllCanteenStaffsTest() {
		List<CanteenStaff> canteenStaff = createCanteenStaffEntityMockData();
		when(canteenStaffRepository.findAll()).thenReturn(canteenStaff);
		
		List<CanteenStaffDto> canteenStaffList = canteenStaffService.getAllStaff();
		
		assert(canteenStaff.size() == canteenStaffList.size());
	}
	private List<CanteenStaff> createCanteenStaffEntityMockData() {
		// TODO Auto-generated method stub
		List<CanteenStaff> canteenStaff = new ArrayList<>();
		CanteenStaff canteenStaffs = new CanteenStaff();
		canteenStaffs.setStaffId((long)100);
		canteenStaffs.setStaffName("pavan");
		canteenStaffs.setStaffEmail("pavan@gmail.com");
		return canteenStaff;
	}


}
